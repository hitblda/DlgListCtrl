﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 Dlg.rc 使用
//
#define IDD_DLG_DIALOG                  102
#define IDD_mainDlg                     102
#define IDR_MAINFRAME                   128
#define IDD_Admin                       130
#define IDD_Infor                       131
#define IDD_Login                       132
#define IDD_Entrance                    133
#define IDC_Input                       1000
#define IDC_NUM                         1001
#define IDC_del                         1001
#define IDC_NAME                        1002
#define IDC_ADMIN                       1002
#define IDC_Salary                      1003
#define IDC_Salary2                     1004
//#define IDC_LIST                        1008
#define IDC_ListMng                     1008
#define IDC_Login                       1009
#define IDC_inforManager                1010
#define IDC_EDIT1                       1004
#define IDC_EDIT2                       1011
#define IDC_EDIT3                       1012
#define IDC_GetInfor                    1013
#define IDC_COMBO1                      1014
#define IDC_Add                         1015
#define IDC_Modify                      1016
#define IDC_ListInfor                   1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
